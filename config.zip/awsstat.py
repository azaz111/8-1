import os
import time
import datetime


time.sleep(250)
i = 0
while i < 1:
        time.sleep(10)
        
        fnon = open("/root/aknomber.txt", "r") 
        ns = fnon.readlines()
        nss = ns[1]
        nss = nss.replace('\n', '')
        nsp = ns[0]
        nsp = nsp.replace('\n', '')
        print(f"Imya Servera  :{nss}")
        fnon.close()
        
        sozd = '/root/aknomber.txt' # Р­С‚Рѕ С„Р°Р№Р» РґР°С‚С‹ СЃРѕР·РґР°РЅРёСЏ
        t2 = os.path.getctime(sozd)
        t2 = t2 + 10800
        print (f"Sozdan : ' {time.ctime(t2) } '")
        
        sub = ": Deleted"   # РЎР»РѕРІРѕ РґР»СЏ РїРѕРёСЃРєР°
        
        sfa = open("/root/rclone1.log", "r") 
        str1 = sfa.read()
        rcl1= str1.count(sub)
        sfa.close()
        #print(f"РџРµСЂРµРґР°РЅРЅРѕ РїР»РѕС‚РѕРІ 1:'{rcl1}'")
        
        try:
           sfa = open("/root/rclone2.log", "r") 
           str2 = sfa.read()
           rcl2= str2.count(sub)
           sfa.close()
        except OSError:
           print(f"Nenaideno rclone2.log'")
           rcl2=0
        
        
        print(f"Plotov peredanno VSEGO  :'{rcl1+rcl2}'")
        
        files = os.listdir(path="/disk4/video")
        plot1 = len(files)
        try:
           files2 = os.listdir(path="/disk4/video1")
           plot2 = len(files2)
        except OSError:
           print(f"Nenaideno video1'")
           plot2=0
        print(f"Plotov na SERVERE : '{plot1+plot2}'")
        
        path = '/disk4/vid2'
        t = os.path.getmtime(path) # РґР°С‚Р° РїРѕСЃР»РµРґРЅРµРіРѕ РёР·РјРµРЅРµРЅРёСЏ С„Р°Р№Р»Р° РѕРЅР° Р¶Рµ РґР°С‚Р° РєРѕРЅРµРєС‚Р°
        t = t + 10800
        print (f"Poslednii raz v seti : ' {time.ctime(t)} '")

        
        t3 = t-t2
        t33 = time.gmtime(t3)
        dop_tame=(t33.tm_mday-1)*24
        print(f"Chasov V Seti : {t33.tm_hour + dop_tame}")

        tst = 150/(rcl1+rcl2+1)
        print(f"Tekischaya Rentabelnost : {tst} rub.plot")

        
        lines = [f"Imya Servera  :{nss}", f"Sozdan : {time.ctime(t2)} ", f"Peredano VSEGO  :{rcl1+rcl2}", f"Plotov na SERVERE: {plot1+plot2}" , f"Poslednii raz v seti : {time.ctime(t)}", f"Chasov V Seti : {t33.tm_hour}", f"Tekischaya Rentabelnost : {tst} rub.plot" ]

        with open(f"/root/{nss}_{nsp}", "w") as filef:
            for  line in lines:
                filef.write(line + '\n')