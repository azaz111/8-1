import json
import os , math , time
from sys import argv
from argparse import ArgumentParser

def transfer(dirs,json,shag):
   
   unique=[]
   
   try:
      n=json
      x=n
   except:
      n=0
      x=n
      pass
   
   while True:
       dirfiles = os.listdir(dirs)
       
       for qqq in  dirfiles:
          if qqq not in unique and os.stat(dirs+'/'+qqq).st_size > 108650979000:
              n+=1
              time.sleep(5)
              print('запускаю транс  ' + qqq + 'На джисоне номер :' + str(n))
              os.system(f'screen -dmS trans{n} rclone move {dirs}/{qqq} aws32: --drive-stop-on-upload-limit --transfers 1 -P --drive-service-account-file "/root/AutoRclone/accounts/{n}.json" -v --log-file /root/rclone1.log;')
              unique.append(qqq)
              if len(unique) > 12:
                 unique.pop(0)
       time.sleep(30)
       if n == x+shag:
          n=x  



if __name__ == '__main__':
    parse = ArgumentParser(description=' Настройка трансфера плотов .')
    parse.add_argument('--pach', default='/disk1', help='Путь c плотами .')
    parse.add_argument('--json', '-j', type=int , default=0 , help='Номер джисона .')
    parse.add_argument('--shag', '-s', type=int , default=5 , help='Шаг смены джисона .')
    args = parse.parse_args()
    transfer(
       dirs=args.pach,
       json=args.json,
       shag=args.shag
    )