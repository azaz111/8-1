from readline import append_history_file
from BIB_API import drive_ls, folder_po_id , service_avtoriz, ls_files_dr_or_fold , bot , createRemoteFolder , spisok_fails_roditelya , nev_json_autoriz , copi_files
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
import subprocess , time
from collections import Counter
from itertools import chain
service = service_avtoriz()
service2 = service_avtoriz('v2')
json_nomber = 0
path = 'accounts'
SCOPES = ["https://www.googleapis.com/auth/drive",
          "https://www.googleapis.com/auth/cloud-platform",
          "https://www.googleapis.com/auth/iam"]
credentials = Credentials.from_authorized_user_file('token.json', SCOPES)


def copi(mud,razn_fold_id,nnk,json_nomber):
   try:
      smena_limit = 0
      service = service_avtoriz()
      mud_id=mud
   
      print('Начинаю копировать папку :' + nnk['name'])
      sozdan=False
      for provfo in spisok_fails_roditelya(razn_fold_id,mud,service):
         #print(provfo)
         if provfo['name'] == nnk['name'] :
            vcopy_fold_id=provfo['id']
            #print('suchestvuet')
            sozdan=True
      if sozdan != True :
         vcopy_fold_id=createRemoteFolder(service2, nnk['name'], razn_fold_id)
   
   
      ls_is=spisok_fails_roditelya(nnk['id'],mud,service) # Список всех файлов В указанной папке исходник 
      spp1=[eee.get('name') for eee in ls_is ]
      ls_naz=spisok_fails_roditelya(vcopy_fold_id,mud,service) # Список всех файлов В указанной папке Назначение
      spp2=[eee.get('name') for eee in ls_naz ]
   
      print(len(ls_is))
      print(len(ls_naz))
   
      lsr=list(set(spp1)-set(spp2))
      print('plan copy '+str(len(lsr)))
      ls=[]
      for i in ls_is:
       spp0=i.get('name')
       if spp0 in lsr:
           ls.append(i)  # Список с разницей
   
      smena_limit=0
      notFound_limit = 0 
      for coi_os in ls:
         josh_limit=0 
         while True:
            json_nomber=json_nomber+1
            if json_nomber >= 101 :
               json_nomber = 1
            service = nev_json_autoriz(json_nomber,SCOPES)
            pez_copy=copi_files(service,coi_os['id'],vcopy_fold_id)
            print(pez_copy)
            if pez_copy == 'cannotCopyFile' or pez_copy == 'uspeh':
               break
            elif josh_limit == 100:
               print('Menyaem')
               print('ПОРА ПЕРЕЕЗЖАТЬ подготовь новый диск: ')
               for eee in drive_ls(service):
                  if eee['id'] == mud_id:
                      mud_osn = eee
               mud_id=mud_osn['id']
               mud_name=mud_osn['name']
               processn = subprocess.Popen(['python3', 'pereezd.py', f'{mud_id}', f'{mud_name}'], stdout=subprocess.PIPE) 
               process = subprocess.Popen(['python3', 'pot_dell.py', f'{mud_id}']) 
   
               mud_id=str(str(processn.stdout.read()[-20:-1]))[2:-1]
               print('new drive - '+ str(mud_id))
               process = subprocess.Popen(['python3', 'fulsmena.py', f'{mud_id}']) 
               process.wait() # 
               print('ZAmenya Uspeh')
               josh_limit=0
               smena_limit+=1
            elif pez_copy == 'userRateLimitExceeded':
               print('schet')
               josh_limit+=1
            elif pez_copy == 'notFound':
               print('schet-notFound')
               notFound_limit+=1
               break
            elif smena_limit == 15:
               print('MNOGO POPITOK')
               exit()
            else:
               print(pez_copy)
      '''ПРОБУЕМ УДАЛИТЬ ДУБЛИ'''
      q=0
      lenss1=ls_files_dr_or_fold(vcopy_fold_id,service) # Список всех файлов
      int_list=[eee.get('name') for eee in lenss1 ] # Список всех Имен файлов
      new_list = list(set(int_list))# Список уникальных имен
      
      final_list_counts = Counter(int_list) - Counter(new_list)
      final_list = list(chain(*[[t] * count for t, count in final_list_counts.items()]))
      
      print("\033[33m{}\033[0m".format('НАХЕРАЧЕЛО ЛИШНИХ ФАЛОВ : '+str(len(final_list))))
      print('----------------------------------------')
      
      service = build('drive', 'v3', credentials=credentials)
      file_ids=[]
      for i in lenss1:
          spp0=i.get('name')
          if spp0 in final_list:
              file_ids.append(i)  # Список с 2 копийями
      nd=[]
      unique = []
      dibles = []
      
      for item in file_ids: 
          #print(item)
          if item['name'] not in unique:
              nd.append(item)      # Уникальные 
              unique.append(item['name']) 
          else:
              dibles.append(item)
      for dir in dibles:  
          q=q+1
          print('Удаляю : ' + str(len(dibles))+ ' C номером '+str(q))
          dir_id=dir.get('id')
          service.files().delete(fileId=dir_id,supportsAllDrives=True).execute()
      ''' Удалили'''
      if len(lsr) == 0 :
         print("\033[32m{}\033[0m".format(' Выполнено Условие Папка успешно скопированна ! '  ))
         #break
      
      print('Ошибок с перемешением : '+str(notFound_limit))
   except:
      print('ERROR : НЕ ОБРАБОТАННАЯ ОШИБКА ')
      bot('ERROR : НЕ ОБРАБОТАННАЯ ОШИБКА '+ nnn ,[292529642])
   return notFound_limit,mud_id




if len(drive_ls(service)) == 1 :
   mud_id=drive_ls(service)[0]['id']
   mud_name=drive_ls(service)[0]['name']
   mud=mud_id
else:
   print( 'НЕ пойму какого хрена вижу больше одного диска ') 
   exit()

print([eee.get('name') for eee in folder_po_id(service,mud_id,mud_id)])
nnn=input('ВВЕДИ ИМЯ ОСНОВНОЙ ПАПКИ С БЕКАПАМИ : ')


process = subprocess.Popen(['python3', 'fulsmena.py', f'{mud}']) 
process.wait() # подготовка к копированию


while True:
   oshinki=0
   rezp=False
   ishodnaya=False
   for sps in folder_po_id(service,mud,mud):  ## Нашли клонируемую или создали
      print(sps)
      name_vsfold = sps.get('name')
      if name_vsfold == nnn :
         iskoma=sps
         ishodnaya=True
      if name_vsfold == nnn+'-copy' :
         razn_fold_id = sps.get('id')
         rezp=True
   
   if ishodnaya != True:
      print('неудалось найти папку с именем  '+ nnn)
   
   if rezp != True:
      razn_fold_id=createRemoteFolder(service2, nnn+'-copy', mud)
   
   ls_id_nado=folder_po_id(service,mud,iskoma['id'])# все папки в исходной
   
   for nnk in ls_id_nado:
      #print(mud,razn_fold_id,nnk)
      rrez=copi(mud,razn_fold_id,nnk,json_nomber)
      mud=rrez[1]
      oshinki=oshinki+rrez[0]
      print('--------------------------------------------------------')

   poisc_isk=False
   poisc_razn=False
   nud=0
   while poisc_isk != True and poisc_razn != True:
      nud+=1
      try:
         if len(drive_ls(service)) == 1 :
            mud_id=drive_ls(service)[0]['id']
            mud_name=drive_ls(service)[0]['name']
            print('Пробую найти  папки для сравнения  ')
            for sps in folder_po_id(service,mud_id,mud_id):  ## Нашли клонируемую и копию
               name_vsfold = sps['name']
               if name_vsfold == nnn :
                  iskoma=sps['id']
                  print("\033[32m{}\033[0m".format(' найдена папка c бекапами :'  ) + iskoma )
                  poisc_isk=True
               if name_vsfold == nnn+'-copy' :
                  razn_fold_id = sps['id']
                  print("\033[32m{}\033[0m".format(' найдена папка с копиями :'  ) + razn_fold_id )
                  poisc_razn=True
         time.sleep(15)
         print('\r Статуст : {}'.format('Ожидаю  удаления дисков для завершения ' + str(nud)), end='')
      except:
         print('НЕСМОГ НАЙТИ ИСКОМУ повторю ')
         time.sleep(15)

   
   print('\nИсходных папок : '+ str(len(ls_files_dr_or_fold(iskoma,service))))
   print('Cкопированно папок : ' + str(len(ls_files_dr_or_fold(razn_fold_id,service))))


   if oshinki < 5:
      print('     -----------------')
      print("\033[32m{}\033[0m".format(' ВЫПОЛНЕНО ! БЕКАП ЗАВЕРШЕН ! Обнаружено ошибок :' +str(oshinki)  ))
      print('     -----------------')
      bot('Закончил бекапить '+ nnn,[292529642])
      break
   else:
      bot('Закончил круг  '+ nnn +' ошибок : ' + str(oshinki) ,[292529642])
