osn_serv=0 # от
osn_lim=100 # До

start_json=0  # от
lim_json=100  # До

server_name='yassel'
tabl_json='yassel_json'