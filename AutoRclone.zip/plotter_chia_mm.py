import os , time , threading
from argparse import ArgumentParser
from random import choice, randint
import subprocess
try:
   from mem_edit import Process
except:
   pass

try:
   os.system(f'apt install cputool')
   os.system(f'pip install mem-edit')
except:
   pass
from mem_edit import Process

def zamorozit_nagruz(nagruz):
   time.sleep(4)
   pid = Process.get_pid_by_name('chia_plot')
   print(pid) 
   while Process.get_pid_by_name('chia_plot')==pid:
      proc=subprocess.Popen(['cputool','--cpu-limit',str(choice(nagruz)),'-p',str(pid)])
      time.sleep(randint(80,450))
      proc.kill()


def plot(scolco,dirs,potok,cpu_nag ,monitorind):
   while True:
      if len(os.listdir(monitorind)) < int(scolco) :
         time.sleep(5)
         print('Start Ploting')
         zap_namber=f'./chia-plotter/build/chia_plot -n {scolco} -r {potok} -u 512 -t / -2 / -d {dirs}/ -f ad04a13ac89fcbc715cbc0b189b2b5ac2e177ec7ed50e1ef045d887008ac1c0569d89af3182e3e2e5bacb81eeab2c0da -c xch19rhzlpu5l45gpm7ms2x4l6swcqt35rux5f6y2jstl35f5v67ceyssrhgvy'
         print(zap_namber)
         x = threading.Thread(target=zamorozit_nagruz, args=([cpu_nag],))
         x.start()
         os.system(f'cd && ' + zap_namber)    
      else:
         print('\r  : {}'.format(' '), end='')  
      time.sleep(20)

if __name__ == '__main__':
    parse = ArgumentParser(description=' Включаем плоттер в зависимрсти от заданного количества .')
    parse.add_argument('--scolco', default='30000', help='Укажи количество плотов в папке .')
    parse.add_argument('--pach', default='/disk1', help='Путь в который плотить .')
    parse.add_argument('--monitorind', default='/disk1', help='Путь по которому мониторить .')
    parse.add_argument('--cpu_nag', '-c' , default='10000', help='Количество нагрузки на цпу.')
    parse.add_argument('--potok', '-p' , default='32', help='Количество цпу сервера.')
    args = parse.parse_args()
    plot(
       scolco=args.scolco,
       dirs=args.pach,
       potok=args.potok,
       cpu_nag=args.cpu_nag,
       monitorind=args.monitorind
    )
