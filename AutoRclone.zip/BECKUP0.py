from readline import append_history_file
from BIB_API import drive_ls, folder_po_id , service_avtoriz, ls_files_dr_or_fold , bot , createRemoteFolder , spisok_fails_roditelya , nev_json_autoriz , copi_files
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
import subprocess , time
from collections import Counter
from itertools import chain
from multiprocessing.pool import ThreadPool
import time,os
import concurrent.futures


service = service_avtoriz()
service2 = service_avtoriz('v2')
json_nomber = 0
path = 'accounts'
SCOPES = ["https://www.googleapis.com/auth/drive",
          "https://www.googleapis.com/auth/cloud-platform",
          "https://www.googleapis.com/auth/iam"]
credentials = Credentials.from_authorized_user_file('token.json', SCOPES)


def copi(mud_id,pap_id_v_copi,pap_id_nado_copi,json_nomber,shag_json):
   try:
      service = service_avtoriz()

      print('Начинаю копировать папку :' + pap_id_nado_copi)

      ls_is=spisok_fails_roditelya(pap_id_nado_copi,mud_id,service) # Список всех файлов В указанной папке исходник 
      spp1=[eee.get('name') for eee in ls_is ]
      ls_naz=spisok_fails_roditelya(pap_id_v_copi,mud_id,service) # Список всех файлов В указанной папке Назначение
      spp2=[eee.get('name') for eee in ls_naz ]
   
      print(len(ls_is))
      print(len(ls_naz))
   
      lsr=list(set(spp1)-set(spp2))
      print('plan copy '+str(len(lsr)))
      ls=[]
      for i in ls_is:
       spp0=i.get('name')
       if spp0 in lsr:
           ls.append(i)  # Список с разницей
   
      notFound_limit = 0 
      json_rab=json_nomber
      for coi_os in ls:
         josh_limit=0 
         while True:
            json_rab=json_rab+1
            if json_rab >= shag_json+json_nomber :
               json_rab =json_nomber
            service = nev_json_autoriz(json_rab,SCOPES)
            pez_copy=copi_files(service,coi_os['id'],pap_id_v_copi)
            print(pez_copy)
            if pez_copy == 'cannotCopyFile' or pez_copy == 'uspeh':
               break
            elif pez_copy == 'userRateLimitExceeded':
               print('schet')
               josh_limit+=1
               input('PAUSE userRateLimitExceeded')
            elif pez_copy == 'notFound':
               print('schet-notFound' + pap_id_v_copi)
               notFound_limit+=1
               input('PAUSE notFound')
               break

            else:
               print(pez_copy)
      '''ПРОБУЕМ УДАЛИТЬ ДУБЛИ'''




      q=0
      lenss1=ls_files_dr_or_fold(pap_id_v_copi,service) # Список всех файлов
      int_list=[eee.get('name') for eee in lenss1 ] # Список всех Имен файлов
      new_list = list(set(int_list))# Список уникальных имен
      
      final_list_counts = Counter(int_list) - Counter(new_list)
      final_list = list(chain(*[[t] * count for t, count in final_list_counts.items()]))
      
      print("\033[33m{}\033[0m".format('НАХЕРАЧЕЛО ЛИШНИХ ФАЛОВ : '+str(len(final_list))))
      print('----------------------------------------')
      
      service = build('drive', 'v3', credentials=credentials)
      file_ids=[]
      for i in lenss1:
          spp0=i.get('name')
          if spp0 in final_list:
              file_ids.append(i)  # Список с 2 копийями
      nd=[]
      unique = []
      dibles = []
      
      for item in file_ids: 
          #print(item)
          if item['name'] not in unique:
              nd.append(item)      # Уникальные 
              unique.append(item['name']) 
          else:
              dibles.append(item)
      for dir in dibles:  
          q=q+1
          print('Удаляю : ' + str(len(dibles))+ ' C номером '+str(q))
          dir_id=dir.get('id')
          service.files().delete(fileId=dir_id,supportsAllDrives=True).execute()
      ''' Удалили'''
      if len(lsr) == 0 :
         print("\033[32m{}\033[0m".format(' Выполнено Условие Папка успешно скопированна ! '  ))
         #break
      
      print('Ошибок с перемешением : '+str(notFound_limit))
   except:
      print('ERROR : НЕ ОБРАБОТАННАЯ ОШИБКА ')
      bot('ERROR : НЕ ОБРАБОТАННАЯ ОШИБКА ',[292529642])
   return notFound_limit,mud_id




ls_pap_id_nado_copi=[]
ls_pap_id_v_copi=[]
ls_id_drive=[]
ls_id_drive=drive_ls(service)
ls_id_drive=[eee.get('id') for eee in ls_id_drive ] 
for id_d in ls_id_drive:
   try:
      paps=folder_po_id(service,id_d,id_d)[0]
      ls_pap_id_nado_copi.append(paps['id'])
      ls_pap_id_v_copi.append(createRemoteFolder(service2, paps['name']+'-copy', id_d))
   except:
      pass
print(ls_id_drive)
print(ls_pap_id_nado_copi)
print(ls_pap_id_v_copi)


#json_nomber=list(range(0,4000,40))
#shag_json=40
#
#executor =concurrent.futures.ThreadPoolExecutor(max_workers=2)
#for i in range(len(ls_id_drive)):
#   executor.submit(copi,ls_id_drive[i],ls_pap_id_v_copi[i],ls_pap_id_nado_copi[i],json_nomber[i],shag_json)
#   #copi(ls_id_drive[i],ls_pap_id_v_copi[i],ls_pap_id_nado_copi[i],0,shag_json)




#i = 1
#for filename in os.listdir(path):
#    os.rename(os.path.join(path,filename), os.path.join(path,str(i)+'.json'))
#    i = i +1 


