import os , time , threading
from argparse import ArgumentParser
from random import choice, randint
try:
   from mem_edit import Process
except:
   pass

try:
   os.system(f'apt install cputool')
   os.system(f'pip install mem-edit')
except:
   pass
from mem_edit import Process


def plot(scolco,dirs,monitorind,cpu):
   
   n=0
   while True:
      if n==4:
         n=0
      n+=1
   
      print('Буду плотить  : '+ str(int(scolco) - len(os.listdir(dirs))))
      if len(os.listdir(dirs)) < int(scolco) :
         nzap=int(scolco) - len(os.listdir(dirs))
         time.sleep(5)
         print('Запускаю Плотинг с ограничением нагрузки ')
         zap_namber=f'cd && ./bladebit/build/bladebit -n {nzap} -f ad04a13ac89fcbc715cbc0b189b2b5ac2e177ec7ed50e1ef045d887008ac1c0569d89af3182e3e2e5bacb81eeab2c0da -p a99700deefa254c48f4316e9b1f5ed3d15d5fc95bb1b8ee7d787750b4610d48f47a382d0611c8706f6135b0f3dbbc53c {dirs}'
         os.system(zap_namber)   

      
      else:
         print('\r Статуст : {}'.format('Ожидаю  передачи '), end='')  
      time.sleep(5)


if __name__ == '__main__':
    parse = ArgumentParser(description=' Включаем плоттер в зависимрсти от заданного количества .')
    parse.add_argument('--scolco','-s', default='400', help='Укажи количество плотов в папке .')
    parse.add_argument('--pach','-p', default='/disk1/', help='Путь в который плотить .')
    parse.add_argument('--monitorind','-m', default='/disk1/', help='Путь по которому мониторить .')
    parse.add_argument('--zagruzka' ,'-cpu ', type=int , default='10000', help='Лимит загрузки CPU .')
    args = parse.parse_args()
    plot(
       scolco=args.scolco,
       dirs=args.pach,
       monitorind=args.monitorind,
       cpu=args.zagruzka,
    )

